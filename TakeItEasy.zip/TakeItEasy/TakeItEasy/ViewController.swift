//
//  ViewController.swift
//  TakeItEasy
//
//  Created by admin on 6/8/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

