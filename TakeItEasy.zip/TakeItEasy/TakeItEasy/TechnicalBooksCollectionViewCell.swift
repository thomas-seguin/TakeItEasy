//
//  TechnicalBooksCollectionViewCell.swift
//  TakeItEasy
//
//  Created by admin on 6/8/22.
//

import UIKit

class TechnicalBooksCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var author: UILabel!
}
